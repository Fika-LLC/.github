let island = document.querySelector(".island");
let ListBtn = document.querySelector(".i-info");
let input1 = document.querySelector("#from");
let input2 = document.querySelector("#to");
let points = input1 || input2;

let numBus = 4
let empty = null

function write(text, animationText, animateIsland, Action) {
  if (text != '') {
    var p = document.createElement("p");
    island.appendChild(p);
    p.innerHTML = text;
    p.classList.add("p")
    p.classList.add(animationText)
    island.classList.add(animateIsland)
    island.setAttribute("onclick", Action)
  }
}
function clear() {
  // Define clear functionality here
  if (island.hasChildNodes()) {
    let p = document.querySelector("p")
    p.remove()
    island.removeAttribute("class")
    island.setAttribute("class", "island")
    
  }
  else {

  }

}

let state = 0; // Initialize the state to 0

function updateState(newState) {
  // Update the state and perform actions based on the new state
  state = newState;

  // Perform actions based on the state
  switch (state) {
    case 0:
      // code
      rest(0)
      break;

    case 1:
      clear();
      state1();
      break;
    case 2:
      clear()
      state2();

    // Add more cases for additional states if needed
  }
}
function rest() {
  let info = "waiting"
  write(info)
}

function state1() {
  // Logic for state 1
  let info = "search";
  write(info, "tracking-in-expand", "noth", "searchC()");
}

function state2(numBus) {
  // Logic for state 2
  let info = `available:4`;

  // Assuming the write function is defined elsewhere and works correctly
  write(info, "grow", "strech");
}

function showList() {
  clear()
  let list = `
      <li>big bus</li>
      <li>bigger bus</li>
      <li>and big bus</li>
    `;
  // Assuming the write function is defined elsewhere and works correctl
  write(list, "grow", "scale");
}
if (state == 0) {
  updateState(0)
}

// Event listeners to trigger state transitions
ListBtn.addEventListener("click", showList)
points.addEventListener("click", () => updateState(1));
island.addEventListener("click", () => updateState(2));
