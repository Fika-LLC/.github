var map = L.map('map').setView([-15.416667,28.283333], 13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

let marker = null;
map.on('click', (event) => {

  if (marker !== null) {
    map.removeLayer(marker);
  }

  marker = L.marker([event.latlng.lat, event.latlng.lng]).addTo(map);

})


// Initialize the map with OpenStreetMap tiles

// Function to search for a city and show it on the map
function searchC() {
  var SearchInput = document.getElementById('from').value;

  if (SearchInput.trim() !== "") {
    // Use Nominatim API for geocoding
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(SearchInput)}`)
      .then(response => response.json())
      .then(data => {
        if (data.length > 0) {
          var city = data[0];
          var coordinates = [parseFloat(city.lat), parseFloat(city.lon)];

          // Remove any existing markers
          map.eachLayer(function (layer) {
            if (layer instanceof L.Marker) {
              map.removeLayer(layer);
            }
          });

          // Add a marker at the city coordinates
          L.marker(coordinates).addTo(map)
            .bindPopup(city.display_name)
            .openPopup();

          // Set the map view to the city coordinates
          map.setView(coordinates, 13);
        } else {
          alert("City not found.");
        }
      })
      .catch(error => {
        console.error(error);
      });
  } else {
    alert("Please enter a city name.");
  }
}

// Function to perform city autocomplete and display suggestions
function autocompleteCity(cityName) {
    if (cityName.trim() !== "") {
        fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(cityName)}`)
            .then(response => response.json())
            .then(data => {
                var suggestions = data.map(city => city.display_name);

                // Display autocomplete suggestions
                displayAutocompleteSuggestions(suggestions);
            })
            .catch(error => {
                console.error(error);
            });
    } else {
        // Clear autocomplete suggestions if input is empty
        displayAutocompleteSuggestions([]);
    }
}

// Function to display autocomplete suggestions
function displayAutocompleteSuggestions(suggestions) {
    var resultsList = document.getElementById('resultsList');
    resultsList.innerHTML = '';

    if (suggestions.length > 0) {
        suggestions.forEach(suggestion => {
            var listItem = document.createElement('li');
            listItem.textContent = suggestion;
            resultsList.appendChild(listItem);
        });
    } else {
        // Display a message when no suggestions are available
        var listItem = document.createElement('li');
        listItem.textContent = "No suggestions found";
        resultsList.appendChild(listItem);
    }
}
