let menu = document.getElementById('menu')
let nav = document.querySelector("nav")
let logo = document.querySelector("#logo")
let acc = document.querySelector("#acc")


function Open() {
  // body...
  nav.classList.toggle("hide")
}
menu.addEventListener("click", Open)


let search = document.querySelector("#search")
let cancel = document.querySelector("#cancel")

search.addEventListener("click", () => {
  search.classList.toggle('hide')
  inputFrom.classList.toggle("hide")
  cancel.classList.toggle("hide")

})

let inputFrom = document.querySelector("#from")
let xlayer = document.querySelector('.extended-layer')
let sugg = document.querySelector("#resultsList")

function Focus() {
  inputFrom.classList.add("focus")
  menu.classList.add("hide")
  logo.classList.add("hide")
  acc.classList.add("hide")
  sugg.classList.remove("hide")
  xlayer.classList.remove("hide")
}
inputFrom.addEventListener("click", Focus)
function unfocus() {
  search.classList.remove("hide")
  sugg.classList.add("hide")
  inputFrom.classList.remove("focus")
  menu.classList.remove("hide")
  logo.classList.remove("hide")
  acc.classList.remove("hide")
  xlayer.classList.add("hide")
  inputFrom.classList.add("hide")
  cancel.classList.add("hide")
}
cancel.addEventListener("click", unfocus)



